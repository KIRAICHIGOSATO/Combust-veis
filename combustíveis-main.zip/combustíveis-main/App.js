import React, { useState } from 'react';
import { StyleSheet, Text, View, TextInput, Button } from 'react-native';

export default function App() {
  const [alcoolValue, setAlcoolValue] = useState('');
  const [gasolinaValue, setGasolinaValue] = useState('');
  const [resultado, setResultado] = useState('');

  const calcularCombustivel = () => {
    const alcool = parseFloat(alcoolValue);
    const gasolina = parseFloat(gasolinaValue);

    if (alcool && gasolina) {
      const resultadoCalculo = alcool / gasolina;
      if (resultadoCalculo < 0.7) {
        setResultado('Abasteça com álcool');
      } else {
        setResultado('Abasteça com gasolina');
      }
    } else {
      setResultado('Digite valores válidos para álcool e gasolina');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Valor do litro do álcool:</Text>
      <TextInput
        style={styles.input}
        keyboardType="numeric"
        value={alcoolValue}
        onChangeText={text => setAlcoolValue(text)}
      />
      <Text style={styles.label}>Valor do litro da gasolina:</Text>
      <TextInput
        style={styles.input}
        keyboardType="numeric"
        value={gasolinaValue}
        onChangeText={text => setGasolinaValue(text)}
      />
      <Button title="Calcular" onPress={calcularCombustivel} />
      <Text style={styles.resultado}>{resultado}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  label: {
    fontSize: 16,
    marginBottom: 5,
  },
  input: {
    width: '100%',
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 10,
    paddingHorizontal: 10,
  },
  resultado: {
    marginTop: 20,
    fontSize: 18,
    fontWeight: 'bold',
  },
});